let board;
let currentPlayer;
let gameOver;
let gameMode = "friend";
let scoreA = 0, scoreB = 0;

window.onload = function () {
  setTimeout(() => {
    document.getElementById("intro").style.display = "none";
    document.getElementById("mainMenu").style.display = "block";
  }, 3000);
};

function startGame(mode) {
  gameMode = mode;
  document.getElementById("mainMenu").style.display = "none";
  document.getElementById("backBtn").style.display = "block";
  document.getElementById("scoreboard").style.display = "block";
  document.getElementById("game").style.display = "grid";
  document.getElementById("status").style.display = "block";
  document.getElementById("restart").style.display = "inline-block";
  resetGame();
}

function goBack() {
  document.getElementById("mainMenu").style.display = "block";
  document.getElementById("backBtn").style.display = "none";
  document.getElementById("scoreboard").style.display = "none";
  document.getElementById("game").style.display = "none";
  document.getElementById("status").style.display = "none";
  document.getElementById("restart").style.display = "none";
}

function makeMove(index) {
  if (board[index] === "" && !gameOver) {
    board[index] = currentPlayer;
    const cell = document.getElementsByClassName("cell")[index];
    cell.textContent = currentPlayer;
    cell.style.color = currentPlayer === "X" ? "red" : "blue";

    if (checkWinner()) {
      let team = currentPlayer === "X" ? "Team A" : "Team B";
      document.getElementById("status").textContent = `${team} Wins!`;
      gameOver = true;
      if (currentPlayer === "X") scoreA++;
      else scoreB++;
      document.getElementById("scoreA").textContent = scoreA;
      document.getElementById("scoreB").textContent = scoreB;
      return;
    }

    if (board.every(cell => cell !== "")) {
      document.getElementById("status").textContent = "Match Draw!";
      gameOver = true;
      return;
    }

    currentPlayer = currentPlayer === "X" ? "O" : "X";
    document.getElementById("status").textContent =
      currentPlayer === "X" ? "Team A's Turn (X)" : "Team B's Turn (O)";

    if (gameMode === "computer" && currentPlayer === "O" && !gameOver) {
      setTimeout(computerMove, 500);
    }
  }
}

function computerMove() {
  let emptyCells = board.map((v, i) => v === "" ? i : null).filter(v => v !== null);
  let move = emptyCells[Math.floor(Math.random() * emptyCells.length)];
  makeMove(move);
}

function checkWinner() {
  const winPatterns = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8],
    [0,4,8], [2,4,6]
  ];
  return winPatterns.some(pattern => {
    const [a, b, c] = pattern;
    return board[a] === currentPlayer && board[b] === currentPlayer && board[c] === currentPlayer;
  });
}

function resetGame() {
  board = ["", "", "", "", "", "", "", "", ""];
  currentPlayer = "X";
  gameOver = false;
  document.querySelectorAll(".cell").forEach(cell => {
    cell.textContent = "";
    cell.style.color = "black";
  });
  document.getElementById("status").textContent = "Team A's Turn (X)";
}